#!/bin/sh
/etc/init.d/mysql start