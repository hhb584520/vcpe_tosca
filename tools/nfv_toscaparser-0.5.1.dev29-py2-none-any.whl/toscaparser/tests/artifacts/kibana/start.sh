#!/bin/bash
# This script starts kibana as a service in init.d
service kibana4 stop
service kibana4 start
